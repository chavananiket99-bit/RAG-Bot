import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  ArrowRight,
  Bot,
  CheckCircle2,
  FileText,
  MessageSquare,
  Search,
  ShieldCheck,
  UploadCloud,
  Activity,
  Sparkles,
} from "lucide-react";

import { useUpload } from "../context/UploadContext";
import UploadCard from "../components/UploadCard";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { uploadedFiles = [], messages = [], documentsLoading } = useUpload();

  const documentCount = uploadedFiles.length;

  const chatCount = messages.filter(
    (message) => message.role === "user",
  ).length;

  const knowledgeStatus = documentCount > 0 ? "Ready" : "Waiting";

  return (
    <div className="min-h-full bg-slate-50">
      <div className="mx-auto w-full max-w-7xl px-4 py-5 sm:px-6 sm:py-6 lg:px-8">
        {/* =====================================================
            HERO
        ====================================================== */}
        <section className="relative overflow-hidden rounded-2xl bg-slate-950 shadow-lg">
          {/* Decorative background */}
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-red-700/20 blur-3xl" />

          <div className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-red-700/10 blur-3xl" />

          <div className="relative px-5 py-7 sm:px-8 sm:py-9 lg:px-10">
            <div className="flex flex-col gap-7 lg:flex-row lg:items-center lg:justify-between">
              {/* Hero content */}
              <div className="max-w-3xl">
                <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900/80 px-3 py-1.5">
                  <Activity size={14} className="text-emerald-400" />

                  <span className="text-xs font-medium text-slate-300">
                    Enterprise AI Workspace
                  </span>
                </div>

                <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl lg:text-4xl">
                  Welcome back, {user?.name || "User"}
                </h1>

                <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">
                  Your intelligent document knowledge workspace. Upload
                  enterprise documents and use AI to find relevant information
                  quickly.
                </p>
              </div>

              {/* Chat CTA */}
              <button
                type="button"
                onClick={() => navigate("/chat")}
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-red-700 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-red-950/30 transition hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-slate-950"
              >
                <Bot size={18} />
                <span>Open AI Chat</span>
                <ArrowRight size={17} />
              </button>
            </div>
          </div>
        </section>

        {/* =====================================================
            STAT CARDS
        ====================================================== */}
        <section className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            label="Documents"
            value={documentsLoading ? "—" : documentCount}
            description="Uploaded knowledge sources"
            icon={FileText}
            iconClass="bg-red-50 text-red-700"
          />

          <StatCard
            label="AI Conversations"
            value={chatCount}
            description="Questions asked in this session"
            icon={MessageSquare}
            iconClass="bg-blue-50 text-blue-600"
          />

          <StatCard
            label="Knowledge Base"
            value={knowledgeStatus}
            description="Document search availability"
            icon={CheckCircle2}
            iconClass="bg-emerald-50 text-emerald-600"
          />

          <StatCard
            label="System"
            value="Online"
            description="AI assistant available"
            icon={ShieldCheck}
            iconClass="bg-emerald-50 text-emerald-600"
          />
        </section>

        {/* =====================================================
            UPLOAD DOCUMENTS
        ====================================================== */}
        <section className="enterprise-card mt-5 p-5 sm:p-6">
          <div className="mb-6 flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50">
              <UploadCloud size={20} className="text-red-700" />
            </div>

            <div>
              <h2 className="enterprise-section-title">Upload Documents</h2>

              <p className="enterprise-section-description">
                Add PDF documents to your enterprise AI knowledge base.
              </p>
            </div>
          </div>

          <div className="flex justify-center">
            <UploadCard />
          </div>
        </section>

        {/* =====================================================
            DOCUMENTS + QUICK ACTIONS
        ====================================================== */}
        <section className="mt-5 grid gap-5 lg:grid-cols-3">
          {/* Recent Documents */}
          <div className="enterprise-card overflow-hidden lg:col-span-2">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
              <div>
                <h2 className="enterprise-section-title">Recent Documents</h2>

                <p className="enterprise-section-description">
                  Documents currently available to the AI
                </p>
              </div>

              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-50">
                <FileText size={18} className="text-slate-500" />
              </div>
            </div>

            <div className="p-3">
              {documentsLoading ? (
                <div className="px-3 py-10 text-center">
                  <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100">
                    <Activity
                      size={19}
                      className="animate-pulse text-slate-400"
                    />
                  </div>

                  <p className="mt-3 text-sm text-slate-400">
                    Loading documents...
                  </p>
                </div>
              ) : documentCount === 0 ? (
                <EmptyDocuments />
              ) : (
                <div className="space-y-1">
                  {uploadedFiles.slice(0, 5).map((document, index) => {
                    const filename =
                      document?.filename ||
                      document?.name ||
                      `Document ${index + 1}`;

                    const documentKey =
                      document?.id ||
                      document?.filename ||
                      document?.name ||
                      index;

                    return (
                      <div
                        key={documentKey}
                        className="group flex items-center gap-3 rounded-xl px-3 py-3 transition hover:bg-slate-50"
                      >
                        {/* PDF icon */}
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-red-50">
                          <FileText size={19} className="text-red-700" />
                        </div>

                        {/* Filename */}
                        <div className="min-w-0 flex-1">
                          <p
                            className="truncate text-sm font-medium text-slate-700 group-hover:text-slate-900"
                            title={filename}
                          >
                            {filename}
                          </p>

                          <p className="mt-0.5 text-xs text-slate-400">
                            {document?.status || "Available for AI search"}
                          </p>
                        </div>

                        {/* Status */}
                        <div className="flex shrink-0 items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1">
                          <CheckCircle2
                            size={13}
                            className="text-emerald-600"
                          />

                          <span className="hidden text-[10px] font-medium text-emerald-700 sm:inline">
                            Ready
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* View all */}
            {documentCount > 5 && (
              <div className="border-t border-slate-100 px-5 py-3">
                <button
                  type="button"
                  onClick={() => navigate("/chat")}
                  className="inline-flex items-center gap-1 text-xs font-medium text-red-700 transition hover:text-red-800"
                >
                  View all documents
                  <ArrowRight size={14} />
                </button>
              </div>
            )}
          </div>

          {/* =====================================================
              QUICK ACTIONS
          ====================================================== */}
          <div className="enterprise-card overflow-hidden">
            <div className="border-b border-slate-100 px-5 py-4">
              <h2 className="enterprise-section-title">Quick Actions</h2>

              <p className="enterprise-section-description">
                Common workspace actions
              </p>
            </div>

            <div className="space-y-2 p-4">
              {/* Ask AI */}
              <QuickAction
                icon={Bot}
                title="Ask AI"
                description="Search your uploaded documents"
                onClick={() => navigate("/chat")}
                highlighted
              />

              {/* Search Knowledge */}
              <QuickAction
                icon={Search}
                title="Search Knowledge"
                description="Find information across documents"
                onClick={() => navigate("/chat")}
              />

              {/* Upload */}
              <QuickAction
                icon={UploadCloud}
                title="Upload Document"
                description="Add another PDF to the knowledge base"
                onClick={() => {
                  document.querySelector('input[type="file"]')?.click();
                }}
              />
            </div>
          </div>
        </section>

        {/* =====================================================
            HOW IT WORKS
        ====================================================== */}
        <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50">
              <Sparkles size={20} className="text-red-700" />
            </div>

            <div>
              <h2 className="enterprise-section-title">
                How Enterprise AI works
              </h2>

              <p className="enterprise-section-description">
                Your documents form the knowledge base used by the AI assistant.
              </p>
            </div>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <WorkflowStep
              number="01"
              title="Upload"
              description="Upload enterprise PDF documents."
            />

            <WorkflowStep
              number="02"
              title="Process"
              description="Documents are extracted and indexed."
            />

            <WorkflowStep
              number="03"
              title="Ask"
              description="Ask natural-language questions."
            />

            <WorkflowStep
              number="04"
              title="Answer"
              description="AI responds using document knowledge."
            />
          </div>
        </section>

        {/* Footer */}
        <div className="py-6 text-center">
          <p className="text-[11px] text-slate-400">
            Mahindra Enterprise AI Knowledge Assistant
          </p>
        </div>
      </div>
    </div>
  );
}

/* =============================================================
   STAT CARD
============================================================= */

function StatCard({ label, value, description, icon: Icon, iconClass }) {
  return (
    <div className="enterprise-card p-5 transition duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
            {label}
          </p>

          <p className="mt-2 truncate text-2xl font-semibold text-slate-800 sm:text-3xl">
            {value}
          </p>

          <p className="mt-1 text-xs text-slate-500">{description}</p>
        </div>

        <div
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${iconClass}`}
        >
          <Icon size={21} />
        </div>
      </div>
    </div>
  );
}

/* =============================================================
   QUICK ACTION
============================================================= */

function QuickAction({
  icon: Icon,
  title,
  description,
  onClick,
  highlighted = false,
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`
        group flex w-full items-center gap-3 rounded-xl border p-3 text-left
        transition
        ${
          highlighted
            ? "border-red-100 bg-red-50/50 hover:border-red-200 hover:bg-red-50"
            : "border-slate-200 hover:border-red-200 hover:bg-red-50/40"
        }
      `}
    >
      <div
        className={`
          flex h-10 w-10 shrink-0 items-center justify-center rounded-lg
          ${highlighted ? "bg-red-100" : "bg-slate-100 group-hover:bg-red-50"}
        `}
      >
        <Icon
          size={19}
          className={
            highlighted
              ? "text-red-700"
              : "text-slate-600 group-hover:text-red-700"
          }
        />
      </div>

      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-slate-700">{title}</p>

        <p className="mt-0.5 truncate text-xs text-slate-400">{description}</p>
      </div>

      <ArrowRight
        size={16}
        className="shrink-0 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-red-600"
      />
    </button>
  );
}

/* =============================================================
   EMPTY DOCUMENTS
============================================================= */

function EmptyDocuments() {
  return (
    <div className="px-3 py-10 text-center">
      <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100">
        <FileText size={21} className="text-slate-400" />
      </div>

      <p className="mt-3 text-sm font-medium text-slate-700">
        No documents yet
      </p>

      <p className="mx-auto mt-1 max-w-xs text-xs leading-5 text-slate-400">
        Upload a PDF to build your enterprise AI knowledge base.
      </p>
    </div>
  );
}

/* =============================================================
   WORKFLOW STEP
============================================================= */

function WorkflowStep({ number, title, description }) {
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50 p-4 transition hover:border-red-100 hover:bg-red-50/30">
      <span className="text-[10px] font-bold tracking-wider text-red-700">
        {number}
      </span>

      <h3 className="mt-2 text-sm font-semibold text-slate-700">{title}</h3>

      <p className="mt-1 text-xs leading-5 text-slate-400">{description}</p>
    </div>
  );
}
