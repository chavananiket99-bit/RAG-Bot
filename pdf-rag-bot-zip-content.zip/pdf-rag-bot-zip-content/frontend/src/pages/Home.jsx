export default function Home() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950">
      <h1 className="text-5xl font-bold text-white">Home Page</h1>
    </div>
  );
}
