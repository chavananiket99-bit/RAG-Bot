import { useState } from "react";
import { Send, Sparkles } from "lucide-react";
export default function ChatInput({ onSend, disabled = false }) {
  const [text, setText] = useState("");
  const handleSend = () => {
    if (disabled) return;
    const value = text.trim();
    if (!value) return;
    onSend(value);
    setText("");
  };
  return (
    <div className="shrink-0 border-t border-slate-200 bg-white px-3 py-3 sm:px-6 sm:py-4">
      <div className="mx-auto w-full max-w-4xl">
        {/* Input container */}
        <div
          className={`flex items-end gap-2 rounded-2xl border bg-slate-50 p-2 shadow-sm transition ${
            disabled
              ? "border-slate-200 opacity-70"
              : "border-slate-300 focus-within:border-red-400 focus-within:ring-2 focus-within:ring-red-100"
          }`}
        >
          {/* AI indicator */}
          <div className="hidden h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white sm:flex">
            <Sparkles size={18} className="text-red-600" />
          </div>
          {/* Text input */}
          <textarea
            rows={1}
            value={text}
            disabled={disabled}
            placeholder={
              disabled
                ? "AI is preparing your answer..."
                : "Ask anything about your uploaded documents..."
            }
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                handleSend();
              }
            }}
            className="max-h-32 min-h-[44px] flex-1 resize-none bg-transparent px-2 py-3 text-sm text-slate-700 outline-none placeholder:text-slate-400 disabled:cursor-not-allowed"
          />
          {/* Send */}
          <button
            type="button"
            onClick={handleSend}
            disabled={disabled || !text.trim()}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-700 text-white shadow-sm transition hover:bg-red-800 disabled:cursor-not-allowed disabled:bg-slate-300"
            title="Send message"
          >
            <Send size={18} />
          </button>
        </div>
        {/* Hint */}
        <div className="mt-2 flex items-center justify-center gap-2 text-[10px] text-slate-400 sm:text-[11px]">
          <span>Enter to send</span>
          <span className="text-slate-300">•</span>
          <span>Shift + Enter for a new line</span>
        </div>
      </div>
    </div>
  );
}
