import { Bot, UserRound, FileText, ChevronDown } from "lucide-react";
import { useState } from "react";
export default function MessageBubble({ sender, text, sources = [] }) {
  const isUser = sender === "user";
  const [showSources, setShowSources] = useState(false);
  return (
    <div
      className={`flex items-start gap-3 ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      {/* AI icon */}
      {!isUser && (
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-50">
          <Bot size={18} className="text-red-700" />
        </div>
      )}
      {/* Message */}
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-6 shadow-sm ${
          isUser
            ? "rounded-tr-md bg-red-700 text-white"
            : "rounded-tl-md border border-slate-200 bg-white text-slate-700"
        }`}
      >
        {/* Answer */}
        <div className="whitespace-pre-wrap break-words">{text}</div>
        {/* Sources */}
        {!isUser && sources.length > 0 && (
          <div className="mt-4 border-t border-slate-100 pt-3">
            <button
              type="button"
              onClick={() => setShowSources((previous) => !previous)}
              className="flex w-full items-center justify-between text-left"
            >
              <div className="flex items-center gap-2">
                <FileText size={14} className="text-red-600" />
                <span className="text-xs font-semibold text-slate-600">
                  Sources ({sources.length})
                </span>
              </div>
              <ChevronDown
                size={15}
                className={`text-slate-400 transition-transform ${
                  showSources ? "rotate-180" : ""
                }`}
              />
            </button>
            {showSources && (
              <div className="mt-3 space-y-2">
                {sources.map((source, index) => (
                  <div
                    key={`${source.document_id}-${source.chunk_index}-${index}`}
                    className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2"
                  >
                    <div className="flex items-start gap-2">
                      <FileText
                        size={14}
                        className="mt-0.5 shrink-0 text-red-600"
                      />
                      <div className="min-w-0">
                        <p
                          className="truncate text-xs font-medium text-slate-700"
                          title={source.filename}
                        >
                          {source.filename}
                        </p>
                        <p className="mt-0.5 text-[10px] text-slate-400">
                          Chunk {source.chunk_index}
                        </p>
                        {source.text && (
                          <p className="mt-2 line-clamp-3 text-[11px] leading-5 text-slate-500">
                            {source.text}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      {/* User icon */}
      {isUser && (
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-200">
          <UserRound size={18} className="text-slate-600" />
        </div>
      )}
    </div>
  );
}
