import { useState } from "react";
import { Bell, ChevronDown, LogOut, Menu, UserRound } from "lucide-react";
import { useNavigate } from "react-router-dom";

import { useAuth } from "../context/AuthContext";

export default function Header({ onMenuClick }) {
  const [profileOpen, setProfileOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <header className="relative z-30 flex h-16 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 shadow-sm md:px-6">
      {/* Left section */}
      <div className="flex items-center gap-3">
        {/* Mobile menu */}
        <button
          type="button"
          onClick={onMenuClick}
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-600 transition hover:bg-slate-100 md:hidden"
          aria-label="Open navigation"
        >
          <Menu size={21} />
        </button>
        {/* Mobile branding */}
        <div className="flex items-center gap-2 md:hidden">
          <img
            src="/mahindra-logo.png"
            alt="Mahindra"
            className="h-8 w-8 object-contain"
          />
          <div className="leading-tight">
            <p className="text-sm font-semibold text-slate-800">Mahindra AI</p>
            <p className="text-[10px] text-slate-400">Knowledge Portal</p>
          </div>
        </div>
        {/* Desktop page branding */}
        <div className="hidden md:block">
          <p className="text-sm font-semibold text-slate-800">
            Enterprise AI Knowledge Assistant
          </p>
          <p className="text-xs text-slate-400">
            Intelligent document knowledge platform
          </p>
        </div>
      </div>
      {/* Right section */}
      <div className="flex items-center gap-2">
        {/* Notifications */}
        <button
          type="button"
          className="relative flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
          title="Notifications"
        >
          <Bell size={19} />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-600 ring-2 ring-white" />
        </button>
        {/* Divider */}
        <div className="mx-1 hidden h-7 w-px bg-slate-200 sm:block" />
        {/* Profile */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setProfileOpen((prev) => !prev)}
            className="flex items-center gap-2 rounded-xl px-2 py-1.5 transition hover:bg-slate-100"
          >
            {/* Avatar */}
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-red-700 text-white">
              <UserRound size={17} />
            </div>
            {/* User information */}
            <div className="hidden text-left sm:block">
              <p className="text-xs font-semibold text-slate-700">
                {user?.name || "User"}
              </p>
              <p className="text-[10px] text-slate-400">
                {user?.username || ""}
              </p>
            </div>
            <ChevronDown
              size={16}
              className={`hidden text-slate-400 transition sm:block ${
                profileOpen ? "rotate-180" : ""
              }`}
            />
          </button>
          {/* Dropdown */}
          {profileOpen && (
            <div className="absolute right-0 mt-2 w-56 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
              {/* Profile header */}
              <div className="border-b border-slate-100 px-4 py-3">
                <p className="text-sm font-semibold text-slate-800">
                  {user?.name || "User"}
                </p>
                <p className="mt-0.5 text-xs text-slate-400">
                  {user?.username || ""}
                </p>
              </div>
              {/* Profile option */}
              <button
                type="button"
                className="flex w-full items-center gap-3 px-4 py-3 text-sm text-slate-600 transition hover:bg-slate-50"
                onClick={() => setProfileOpen(false)}
              >
                <UserRound size={17} />
                <span>My Profile</span>
              </button>
              {/* Logout */}
              <button
                type="button"
                className="flex w-full items-center gap-3 border-t border-slate-100 px-4 py-3 text-sm text-red-600 transition hover:bg-red-50"
                onClick={handleLogout}
              >
                <LogOut size={17} />
                <span>Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
