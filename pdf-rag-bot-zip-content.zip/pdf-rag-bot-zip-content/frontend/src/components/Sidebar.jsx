import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Bot,
  FileText,
  Loader2,
  ChevronRight,
  X,
} from "lucide-react";
import { useUpload } from "../context/UploadContext";
export default function Sidebar({ mobileOpen = false, onClose }) {
  const { uploadedFiles, documentsLoading } = useUpload();
  const location = useLocation();
  const isActive = (path) => location.pathname === path;
  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-950/50 backdrop-blur-sm md:hidden"
        />
      )}
      {/* Sidebar */}
      <aside
        className={`
         fixed inset-y-0 left-0 z-50 flex w-72 flex-col
         border-r border-slate-800 bg-slate-950 text-slate-300
         shadow-2xl transition-transform duration-300
         md:static md:z-auto md:h-screen md:w-64
         md:translate-x-0 md:shadow-none
         ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
       `}
      >
        {/* Brand */}
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-slate-800 px-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white">
              <img
                src="/mahindra-logo.png"
                alt="Mahindra"
                className="h-7 w-7 object-contain"
              />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Mahindra AI</p>
              <p className="text-[10px] text-slate-500">Knowledge Portal</p>
            </div>
          </div>
          {/* Mobile close */}
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-500 hover:bg-slate-900 hover:text-white md:hidden"
            aria-label="Close navigation"
          >
            <X size={19} />
          </button>
        </div>
        {/* Workspace */}
        <div className="px-3 py-5">
          <p className="mb-3 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-600">
            Workspace
          </p>
          <nav className="space-y-1">
            <Link
              to="/dashboard"
              onClick={onClose}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive("/dashboard")
                  ? "bg-red-700 text-white shadow-sm"
                  : "text-slate-400 hover:bg-slate-900 hover:text-white"
              }`}
            >
              <LayoutDashboard size={18} />
              <span>Dashboard</span>
              {isActive("/dashboard") && (
                <ChevronRight size={16} className="ml-auto" />
              )}
            </Link>
            <Link
              to="/chat"
              onClick={onClose}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                isActive("/chat")
                  ? "bg-red-700 text-white shadow-sm"
                  : "text-slate-400 hover:bg-slate-900 hover:text-white"
              }`}
            >
              <Bot size={18} />
              <span>AI Chat</span>
              {isActive("/chat") && (
                <ChevronRight size={16} className="ml-auto" />
              )}
            </Link>
          </nav>
        </div>
        {/* Documents */}
        <div className="min-h-0 flex-1 px-3">
          <div className="mb-3 flex items-center justify-between px-3">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-600">
              Documents
            </p>
            {!documentsLoading && (
              <span className="rounded-full bg-slate-900 px-2 py-0.5 text-[10px] text-slate-400">
                {uploadedFiles.length}
              </span>
            )}
          </div>
          {documentsLoading && (
            <div className="flex items-center gap-2 px-3 py-3 text-xs text-slate-500">
              <Loader2 size={15} className="animate-spin" />
              <span>Loading documents...</span>
            </div>
          )}
          {!documentsLoading && uploadedFiles.length === 0 && (
            <div className="mx-1 rounded-xl border border-dashed border-slate-800 px-3 py-5 text-center">
              <FileText size={22} className="mx-auto mb-2 text-slate-600" />
              <p className="text-xs text-slate-600">No documents uploaded</p>
            </div>
          )}
          {!documentsLoading && uploadedFiles.length > 0 && (
            <div className="max-h-[calc(100vh-280px)] space-y-1 overflow-y-auto pr-1">
              {uploadedFiles.map((document, index) => {
                const filename =
                  document?.filename ||
                  document?.name ||
                  `Document ${index + 1}`;
                return (
                  <div
                    key={
                      document?.id ||
                      document?.filename ||
                      document?.name ||
                      index
                    }
                    className="group flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-slate-900"
                    title={filename}
                  >
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-950/50">
                      <FileText size={16} className="text-red-500" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-slate-300 group-hover:text-white">
                        {filename}
                      </p>
                      <p className="mt-0.5 text-[10px] text-slate-600">
                        {document?.status || "Indexed"}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
        {/* Footer */}
        <div className="shrink-0 border-t border-slate-800 px-5 py-4">
          <p className="text-[10px] uppercase tracking-wider text-slate-600">
            Mahindra Enterprise AI
          </p>
          <p className="mt-1 text-[10px] text-slate-700">Knowledge Assistant</p>
        </div>
      </aside>
    </>
  );
}
