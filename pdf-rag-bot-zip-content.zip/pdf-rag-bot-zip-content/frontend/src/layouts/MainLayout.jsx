import { useState } from "react";
import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
export default function MainLayout({ children }) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const openMobileSidebar = () => {
    setMobileSidebarOpen(true);
  };
  const closeMobileSidebar = () => {
    setMobileSidebarOpen(false);
  };
  return (
    <div className="flex h-screen overflow-hidden bg-slate-100">
      {/* Sidebar */}
      <Sidebar mobileOpen={mobileSidebarOpen} onClose={closeMobileSidebar} />
      {/* Main application */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Header */}
        <Header onMenuClick={openMobileSidebar} />
        {/* Content */}
        <main className="min-h-0 flex-1 overflow-y-auto">
          <div className="min-h-full w-full">{children}</div>
        </main>
      </div>
    </div>
  );
}
