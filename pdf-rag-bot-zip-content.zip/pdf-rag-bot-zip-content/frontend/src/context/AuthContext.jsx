import { createContext, useContext, useEffect, useMemo, useState } from "react";
const AuthContext = createContext(null);
const AUTH_STORAGE_KEY = "rag_auth";

function loadStoredAuth() {
  try {
    const saved = localStorage.getItem(AUTH_STORAGE_KEY);
    if (!saved) {
      return null;
    }
    const parsed = JSON.parse(saved);
    if (!parsed?.user || !parsed?.accessToken) {
      localStorage.removeItem(AUTH_STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch (error) {
    console.error("Failed to restore authentication:", error);
    localStorage.removeItem(AUTH_STORAGE_KEY);
    return null;
  }
}
export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(() => loadStoredAuth());
  useEffect(() => {
    if (auth) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(auth));
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
  }, [auth]);
  const login = async ({ username, password }) => {
    if (!username?.trim() || !password) {
      throw new Error("Username and password are required.");
    }
    const apiBaseUrl =
      import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";
    const response = await fetch(`${apiBaseUrl}/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username: username.trim(),
        password,
      }),
    });
    let data = {};
    try {
      data = await response.json();
    } catch {
      data = {};
    }
    if (!response.ok) {
      throw new Error(
        data?.detail ||
          data?.message ||
          "Unable to sign in. Please check your credentials.",
      );
    }
    if (!data?.access_token || !data?.user) {
      throw new Error("Authentication response is invalid.");
    }
    const authenticatedUser = data.user;
    const authData = {
      user: authenticatedUser,
      accessToken: data.access_token,
      tokenType: data.token_type || "bearer",
    };
    setAuth(authData);
    return authenticatedUser;
  };
  const loginWithSSO = async () => {
    throw new Error("Corporate SSO is not implemented yet.");
  };
  const logout = () => {
    setAuth(null);
  };
  const value = useMemo(
    () => ({
      user: auth?.user || null,
      accessToken: auth?.accessToken || null,
      tokenType: auth?.tokenType || "bearer",
      isAuthenticated: Boolean(auth?.user && auth?.accessToken),
      login,
      loginWithSSO,
      logout,
    }),
    [auth],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
