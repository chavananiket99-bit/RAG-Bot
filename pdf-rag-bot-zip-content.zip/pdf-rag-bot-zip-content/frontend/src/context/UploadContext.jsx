import { useAuth } from "../context/AuthContext";
import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";
import { getDocuments } from "../services/api";
const UploadContext = createContext();
/*
 * Convert backend documents into one standard frontend format.
 */
function normalizeDocument(doc, index = 0) {
  if (!doc) return null;
  // Backend document
  if (typeof doc === "object") {
    return {
      id:
        doc.id ||
        doc.file_id ||
        doc.filename ||
        doc.name ||
        `document-${index}`,
      filename: doc.filename || doc.name || "Unnamed document",
      status: doc.status || "Indexed",
    };
  }
  // Fallback for string filenames
  if (typeof doc === "string") {
    return {
      id: doc,
      filename: doc,
      status: "Indexed",
    };
  }
  return null;
}
function normalizeDocuments(documents) {
  if (!Array.isArray(documents)) {
    return [];
  }
  return documents
    .map((doc, index) => normalizeDocument(doc, index))
    .filter(Boolean);
}
export function UploadProvider({ children }) {
  const { isAuthenticated } = useAuth();

  const [uploadedFiles, setUploadedFiles] = useState(() => {
    try {
      const saved = localStorage.getItem("uploadedFiles");
      if (!saved) {
        return [];
      }
      const parsed = JSON.parse(saved);
      return normalizeDocuments(parsed);
    } catch (error) {
      console.error("Failed to restore uploaded files:", error);
      return [];
    }
  });
  const [messages, setMessages] = useState(() => {
    try {
      const saved = localStorage.getItem("messages");
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error("Failed to restore messages:", error);
      return [];
    }
  });
  const [loading, setLoading] = useState(false);
  const [typing, setTyping] = useState(false);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [documentsLoading, setDocumentsLoading] = useState(false);
  /*
   * Load documents from backend.
   */
  const refreshDocuments = useCallback(async () => {
    try {
      setDocumentsLoading(true);
      const data = await getDocuments();
      const backendDocuments = data?.documents || [];
      const normalizedDocuments = normalizeDocuments(backendDocuments);
      setUploadedFiles(normalizedDocuments);
    } catch (error) {
      console.error("Failed to load documents from backend:", error);
    } finally {
      setDocumentsLoading(false);
    }
  }, []);
  /*
   * Persist uploaded documents.
   */
  useEffect(() => {
    localStorage.setItem("uploadedFiles", JSON.stringify(uploadedFiles));
  }, [uploadedFiles]);
  /*
   * Persist chat messages.
   */
  useEffect(() => {
    localStorage.setItem("messages", JSON.stringify(messages));
  }, [messages]);
  /*
   * Load backend documents when application starts.
   */
  useEffect(() => {
    if (!isAuthenticated) {
      setUploadedFiles([]);
      return;
    }
    refreshDocuments();
  }, [isAuthenticated, refreshDocuments]);
  return (
    <UploadContext.Provider
      value={{
        uploadedFiles,
        setUploadedFiles,
        messages,
        setMessages,
        loading,
        setLoading,
        typing,
        setTyping,
        currentConversation,
        setCurrentConversation,
        documentsLoading,
        refreshDocuments,
      }}
    >
      {children}
    </UploadContext.Provider>
  );
}
export function useUpload() {
  return useContext(UploadContext);
}
