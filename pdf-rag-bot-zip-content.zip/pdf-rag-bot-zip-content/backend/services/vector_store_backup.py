import json
import logging
import threading
from pathlib import Path

import faiss
import numpy as np

from services.embedding_service import embedding_service

logger = logging.getLogger("uvicorn.error")

BASE_DIR = Path(__file__).resolve().parent.parent
INDEX_DIR = BASE_DIR / "indexes"

FAISS_INDEX_FILE = INDEX_DIR / "faiss.index"
METADATA_FILE = INDEX_DIR / "faiss_metadata.json"

class FAISSVectorStore:
    def __init__(self):
        INDEX_DIR.mkdir(parents=True, exist_ok=True)

        self.lock = threading.Lock()

        self.dimension = (
            embedding_service.model.get_embedding_dimension()
        )

        self.index = None
        self.metadata = {}
        self.next_vector_id = 1

        self._load()

    def _load(self):
        """
        Load the FAISS index and metadata from disk.
        """

        if FAISS_INDEX_FILE.exists() :

            logger.info("Loading FAISS index from disk: %s", FAISS_INDEX_FILE)

            self.index = faiss.read_index(str(FAISS_INDEX_FILE))

        else:
            logger.info("Creating a new FAISS index. Dimension: %s", self.dimension)

            base_index = faiss.IndexFlatIP(self.dimension)
            self.index = faiss.IndexIDMap2(base_index)

        if METADATA_FILE.exists():
            try:
                with open(METADATA_FILE, "r", encoding="utf-8") as file:
                    data = json.load(file)

                self.metadata = data.get("metadata", {})

                self.next_vector_id = data.get("next_vector_id", 1)

            except Exception as exc:
                logger.error("Failed to load FAISS metadata: %s", exc)

                self.metadata = {}
                self.next_vector_id = 1

        logger.info(
            "FAISS vector count: %s", self.index.ntotal
        )

        logger.info(
            "FAISS metadata entries: %s", len(self.metadata)
        )
                

    def _save(self):
        """
        Persist FAISS index and metadata to disk.
        """

        temp_index_file = FAISS_INDEX_FILE.with_suffix(".tmp")

        faiss.write_index(self.index, str(temp_index_file))

        temp_index_file.replace(FAISS_INDEX_FILE)

        data = {
            "next_vector_id": self.next_vector_id,
            "metadata": self.metadata
        }

        temp_metadata_file = METADATA_FILE.with_suffix(".tmp")

        with open(temp_metadata_file, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=2, ensure_ascii=False)

        temp_metadata_file.replace(METADATA_FILE)

    def add_document(self, document_id, filename, chunks):
        """
        Add a document's chunks to the FAISS index.

        Each chunk is embedded and added to the index with associated metadata.
        """

        if not chunks:
            return 0

        cleaned_chunks = [chunk.strip() for chunk in chunks if chunk and chunk.strip()]

        if not cleaned_chunks:
            return 0

        logger.info(
            "Creating embedding for document: %s", filename
        )

        embeddings = embedding_service.embed_documents(cleaned_chunks)

        vectors = np.asarray(embeddings, dtype="float32")

        vector_ids = []

        metadata_entries = {}

        with self.lock:
            for index, chunk in enumerate(cleaned_chunks):
                vector_id = self.next_vector_id
                self.next_vector_id += 1

                vector_ids.append(vector_id)

                metadata_entries[str(vector_id)] = {
                    "document_id": document_id,
                    "filename": filename,
                    "chunk_index": index,
                    "text": chunk
                }

            ids = np.asarray(vector_ids, dtype="int64")

            self.index.add_with_ids(vectors, ids)

            self.metadata.update(metadata_entries)

            self._save()

        logger.info(
            "Added %s chunks to FAISS for document %s", len(cleaned_chunks), document_id
        )

        logger.info(
            "Total vectors in FAISS: %s", self.index.ntotal
        )

        return len(cleaned_chunks)

    def search(self, query, top_k=5):
        if not query or not query.strip():
            return []

        if self.index.ntotal == 0:
            return []

        query_embedding = embedding_service.embed_text(query)

        query_vector = np.asarray([query_embedding], dtype="float32")

        scores, vectors_ids = self.index.search(query_vector, top_k)

        results = []

        for score, vector_id in zip(scores[0], vectors_ids[0]):
            if vector_id == -1:
                continue

            metadata = self.metadata.get(str(int(vector_id)))

            if not metadata:
                continue

            results.append({
                "score": float(score),
                "vector_id": int(vector_id),
                "document_id": metadata["document_id"],
                "filename": metadata["filename"],
                "chunk_index": metadata["chunk_index"],
                "text": metadata["text"]
            })
        return results

    def delete_document(self, document_id):
        """
        Remove all chunks associated with a document from the FAISS index.
        """

        vector_ids = []

        for vector_id, metadata in self.metadata.items():
            if metadata.get("document_id") == document_id:
                vector_ids.append(int(vector_id))

        if not vector_ids:
            logger.info("No FAISS vectors found for document: %s", document_id)
            return 0

        with self.lock:

            ids = np.asarray(vector_ids, dtype="int64")

            removed = self.index.remove_ids(ids)

            for vector_id in vector_ids:
                self.metadata.pop(str(vector_id), None)

            self._save()

        logger.info(
            "Removed %s vectors for document: %s", removed, document_id
        )

        logger.info(
            "Total vectors in FAISS after deletion: %s", self.index.ntotal
        )

        return int(removed)

    def get_document_vector_count(self, document_id):
        """
        Get the number of vectors associated with a document.
        """

        count = 0

        for metadata in self.metadata.values():
            if metadata.get("document_id") == document_id:
                count += 1

        return count

    def get_total_vector_count(self):
        """
        Get the total number of vectors in the FAISS index.
        """

        return self.index.ntotal

vector_store = FAISSVectorStore()
        