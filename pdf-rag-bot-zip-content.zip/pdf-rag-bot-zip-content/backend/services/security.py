import os
from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt

SECRET_KEY = os.getenv(
    "JWT_SECRET_KEY",
    "development-only-change-this-secret"
)

ALGORITHM = "HS256"

ACCESS_TOKEN_EXPIRE_MINUTES = int(
    os.getenv(
        "ACCESS_TOKEN_EXPIRE_MINUTES",
        "60"
    )
)

def create_access_token(
    user: dict,
):
    """
    Create a JWT access token for an authenticated user.
    """
    now = datetime.now(
        timezone.utc
    )
    expire = now + timedelta(
        minutes=ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {
        "sub": str(
            user.get("id")
        ),
        "username": user.get(
            "username"
        ),
        "name": user.get(
            "name"
        ),
        "loginType": user.get(
            "loginType",
            "form"
        ),
        "iat": now,
        "exp": expire,
    }
    return jwt.encode(
        payload,
        SECRET_KEY,
        algorithm=ALGORITHM,
    )

def decode_access_token(
    token: str,
):
    """
    Decode and validate an access token.
    """
    try:
        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM],
        )
        return payload
    except JWTError:
        return None