import hashlib
import hmac
import os
from datetime import datetime, timedelta, timezone
import jwt

class AuthService:
    """
    Development authentication service.
    Phase 1:
    - Validates development credentials
    - Generates JWT access tokens
    - Validates JWT access tokens
    This is intentionally kept simple for the current development
    environment. Corporate SSO / database-backed users can be added later.
    """
    DEMO_USERNAME = os.getenv("DEMO_USERNAME", "demo")
    DEMO_PASSWORD = os.getenv("DEMO_PASSWORD", "demo123")

    JWT_SECRET_KEY = os.getenv(
        "JWT_SECRET_KEY",
        "CHANGE_THIS_DEVELOPMENT_SECRET_KEY",
    )

    JWT_ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 60

    @classmethod
    def authenticate(cls, username: str, password: str):
        username = username.strip()
        if not username or not password:
            return None
        username_valid = hmac.compare_digest(
            username,
            cls.DEMO_USERNAME,
        )

        password_valid = hmac.compare_digest(
            password,
            cls.DEMO_PASSWORD,
        )

        if not username_valid or not password_valid:
            return None

        return {
            "id": "demo-user",
            "name": "Demo User",
            "username": username,
            "loginType": "form",
        }

    @classmethod
    def create_access_token(cls, user: dict) -> str:
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(
            minutes=cls.ACCESS_TOKEN_EXPIRE_MINUTES
        )

        payload = {
            "sub": user["id"],
            "username": user["username"],
            "name": user["name"],
            "loginType": user.get("loginType", "form"),
            "iat": now,
            "exp": expires_at,
        }

        return jwt.encode(
            payload,
            cls.JWT_SECRET_KEY,
            algorithm=cls.JWT_ALGORITHM,
        )

    @classmethod
    def decode_access_token(cls, token: str) -> dict:
        try:
            payload = jwt.decode(
                token,
                cls.JWT_SECRET_KEY,
                algorithms=[cls.JWT_ALGORITHM],
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise ValueError("Authentication token has expired.")
        except jwt.InvalidTokenError:
            raise ValueError("Invalid authentication token.")

auth_service = AuthService()