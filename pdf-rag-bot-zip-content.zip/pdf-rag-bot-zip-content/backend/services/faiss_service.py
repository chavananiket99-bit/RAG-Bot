import json
import logging
from pathlib import Path

import faiss
import numpy as np

logger = logging.getLogger("uvicorn.error")

BASE_DIR = Path(__file__).resolve().parent.parent
INDEX_DIR = BASE_DIR / "indexes"

INDEX_FILE = INDEX_DIR / "documents.index"
METADATA_FILE = INDEX_DIR / "documents_metadata.json"

class FAISSService:
    def __init__(self):
        INDEX_DIR.mkdir(parents=True, exist_ok=True)

        self.index = None
        self.metadata = []

        self._load()

    def _load(self):
        """
        Load the FAISS index and metadata from disk.
        """

        if INDEX_FILE.exists() and METADATA_FILE.exists():
            try:
                self.index = faiss.read_index(str(INDEX_FILE))

                with open(METADATA_FILE, "r", encoding="utf-8") as file:
                    self.metadata = json.load(file)

                logger.info("FAISS index loaded: %s vectors", self.index.ntotal,)

            except Exception as exc:
                logger.error("Failed to load FAISS index: %s", exc,)
                self.index = None
                self.metadata = []

    def _save(self):
        """
        Persist FAISS index and metadata to disk.
        """

        if self.index is not None:
            faiss.write_index(self.index, str(INDEX_FILE))

            with open(METADATA_FILE, "w", encoding="utf-8") as file:
                json.dump(self.metadata, file, indent=4, ensure_ascii=False,)

    def initialize(self, dimension):
        """
        Create an empty FAISS index.

        We use IndexFlatIP because embeddings will be normalized, making inner product equivalent to cosine similarity.
        """

        if self.index is None:
            self.index = faiss.IndexFlatIP(dimension)
            self.metadata = []

            self._save()

            logger.info("Create new FAISS index with dimension %s", dimension)

    def add_embeddings(self, embeddings, document_id, filename, chunks,):
        """
        Add document chunk embeddings to the FAISS.

        Each embedding is associated with metadata containing the document ID, filename, and chunk text.
        """

        if not embeddings:
            return

        vectors = np.asarray(embeddings, dtype="float32")

        if vectors.ndim != 2:
            raise ValueError("Embeddings must be a 2-dimensional array")

        faiss.normalize_L2(vectors)

        dimension = vectors.shape[1]

        self.initialize(dimension)

        if self.index.d != dimension:
            raise ValueError(
                f"Embedding dimension mismatch. "
                f"Existing index: {self.index.d}, "
                f"New embeddings: {dimension}"
            )

        self.index.add(vectors)

        start_index = len(self.metadata)

        for chunk_index, chunk in enumerate(chunks):
            self.metadata.append(
                {
                    "vector_id": start_index + chunk_index,
                    "document_id": document_id,
                    "filename": filename,
                    "chunk_index": chunk_index,
                    "text": chunk,
                }
            )

        self._save()

        logger.info(
            "Added %s chunks for document %s", len(chunks), document_id
        )

    def search(self, query_embedding, top_k=5):
        """"
        Search the most relevant chunks
        """

        if self.index is None or self.index.ntotal == 0:
            return []

        query_vector = np.asarray([query_embedding], dtype="float32")

        faiss.normalize_L2(query_vector)

        k = min(top_k, self.index.ntotal)

        scores, indices = self.index.search(query_vector, k)

        results = []

        for score, index in zip(scores[0], indices[0]):
            if index < 0:
                continue

            if index >= len(self.metadata):
                continue

            metadata = self.metadata[index].copy()

            metadata["score"] = float(score)

            results.append(metadata)

        return results

faiss_service = FAISSService()