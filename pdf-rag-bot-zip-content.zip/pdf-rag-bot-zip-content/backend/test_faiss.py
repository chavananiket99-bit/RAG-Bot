from services.vector_store import vector_store

print("\n========== FAISS TEST ==========\n")
# 1. Test adding a document
document_id = "test-document-001"
filename = "test.pdf"
chunks = [
   "Mahindra is an Indian multinational automotive manufacturing company.",
   "The company manufactures automobiles, commercial vehicles and tractors.",
   "Mahindra was founded in 1945.",
]
print("Adding test document...")
added = vector_store.add_document(
   document_id=document_id,
   filename=filename,
   chunks=chunks,
)
print(f"Chunks added: {added}")

# 2. Check total vectors
total_vectors = vector_store.get_total_vector_count()
print(f"Total vectors in FAISS: {total_vectors}")

# 3. Test similarity search
query = "When was Mahindra founded?"
print(f"\nSearching for: {query}")
results = vector_store.search(
   query=query,
   top_k=3,
)

# 4. Display results
print("\n========== SEARCH RESULTS ==========\n")
for index, result in enumerate(results, start=1):
   print(f"Result {index}")
   print(f"Score: {result['score']:.4f}")
   print(f"Filename: {result['filename']}")
   print(f"Chunk index: {result['chunk_index']}")
   print(f"Text: {result['text']}")
   print("-" * 60)

# 5. Delete test document
print("\nDeleting test document...")
deleted = vector_store.delete_document(document_id)
print(f"Vectors deleted: {deleted}")
print(
   f"Total vectors after deletion: "
   f"{vector_store.get_total_vector_count()}"
)
print("\n========== FAISS TEST COMPLETE ==========\n")